---
id: "FORGE-code-analysis"
name: "forge-code-analysis"
description: "DEPRECATED ALIAS (2026-10-14) — canonical_owner: forge-code-analysis. do_not_select: true. Live skill: /root/AAA/skills/forge-code-analysis. Entropy consolidation 2026-10-14 by 333-AGI (F13 order)."
owner: "333-AGI"
risk_tier: "low"
autonomy_tier: "T0"
floor_scope: [F2, F12]
forged: "2026-10-14"
forged_by: "333-AGI"
---

# FORGE-code-analysis → forge-code-analysis

This directory is a retired alias door. All content lives at `/root/AAA/skills/forge-code-analysis`.
Do not select this skill; load `forge-code-analysis` instead.
