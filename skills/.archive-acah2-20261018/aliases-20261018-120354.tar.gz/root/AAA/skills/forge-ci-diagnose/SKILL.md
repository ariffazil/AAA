---
id: "forge-ci-diagnose"
name: "forge-repo-intelligence"
description: "DEPRECATED ALIAS (2026-10-14) — canonical_owner: forge-repo-intelligence. do_not_select: true. Live skill: /root/AAA/skills/forge-repo-intelligence. Entropy consolidation 2026-10-14 by 333-AGI (F13 order)."
owner: "333-AGI"
risk_tier: "low"
autonomy_tier: "T0"
floor_scope: [F2, F12]
forged: "2026-10-14"
forged_by: "333-AGI"
---

# forge-ci-diagnose → forge-repo-intelligence

This directory is a retired alias door. All content lives at `/root/AAA/skills/forge-repo-intelligence`.
Do not select this skill; load `forge-repo-intelligence` instead.
