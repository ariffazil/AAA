---
name: arifos-router
description: Route a capability gap to the correct federation organ tool — the gap-to-door map for the canonical eight.
triggers: USE WHEN: unsure which arif_* tool or organ fits a task; USE WHEN: planning tool selection before execution.
evidence_tier: NORMATIVE (canon) 
---

# arifos-router — gap → door

Select by GAP, never by habit. The canonical eight (kernel door `arifos`):

| Gap | Tool | Note |
|---|---|---|
| No session yet | `arif_init` | binds actor + floors; start here |
| Evidence missing | `arif_observe` | search/fetch/vitals/repo map |
| Reasoning missing | `arif_think` | plan/analyze/verify (critique via mode) |
| Tool uncertainty | `arif_route` | intent → organ dispatch |
| Memory gap | `arif_memory` | recall/inspect/attest/promote/revise |
| Decision time | `arif_judge` | SEAL/HOLD/SABAR/VOID |
| Ready to execute | `arif_forge` | governed execution; mutation after SEAL only |
| Finality needed | `arif_seal` | VAULT999 immutable append |

Organ doors beyond the kernel: `aforge` (execution substrate, forge_* verbs),
`geox` (earth intelligence), `wealth` (capital intelligence), `well`
(vitality/triadic state). Full unified surface lives server-side at the
federation door — probe it; never quote a tool count from memory
(sensor, not quote).

LAW: capability here, authority in the federation. If the doors are
unreachable → OBSERVE_ONLY; do not improvise local authority.
