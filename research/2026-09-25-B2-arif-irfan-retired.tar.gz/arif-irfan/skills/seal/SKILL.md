---
name: seal
description: Session close ritual — receipt inventory, seal recommendation, graceful offline close.
triggers: USE WHEN: session ending; USE WHEN: finality needed for the session's claims; USE WHEN: stop event fired.
evidence_tier: NORMATIVE (canon)
---

# seal — close

1. Read today's receipt inventory (the Stop hook prints it):
   `~/.cache/arifos-plugin/receipts.jsonl` — every entry carries trace_id.
2. Unclosed transitions are not failures; they are the next seal window's
   input. List them, don't hide them.
3. When finality is wanted: `arif_seal` on the kernel door with a compact
   payload of the session's claims + their states
   (ESTIMATED → MEASURED → CROSS_VALIDATED; RETRACTED/SUPERSEDED honored).
4. Offline close: ledger stands local; next bound session mirrors it.
   Never fabricate a seal you cannot reach.

A session that receipts everything and seals what matters is closed —
even if it ended quietly.
