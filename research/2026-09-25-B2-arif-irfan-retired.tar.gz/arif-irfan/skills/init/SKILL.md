---
name: init
description: Federation ignition for a Codex session — bind, load context, state the golden path.
triggers: USE WHEN: session start; USE WHEN: no bound session_id; USE WHEN: first tool selection of a session.
evidence_tier: NORMATIVE (canon)
---

# init — ignition

1. If the SessionStart hook bound a session, its id sits in
   `~/.cache/arifos-plugin/session.json`. Read it; pass `session_id` on
   kernel tool calls.
2. If unbound (hook failed or offline), call `arif_init` yourself:
   actor `codex-plugin/arif-irfan`, authority `OBSERVE_ONLY`.
3. Load live context from kernel resources when reachable:
   `arifos://bootstrap`, `arifos://carry-forward`, `arifos://flow-state`
   (FQ < 0.5 → OBSERVE_ONLY).
4. State the golden path in your first reply:
   init → observe → think → route → memory → judge → forge → seal.

Hard rules from the spine: irreversible class (`rm -rf`, `DROP TABLE`,
force-push to main, new paid API) is hard-blocked and goes to Arif as ONE
binary. Everything reversible executes with receipts.
