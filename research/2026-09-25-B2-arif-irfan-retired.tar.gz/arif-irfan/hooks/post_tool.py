#!/usr/bin/env python3
"""post_tool.py — arif-irfan witness lane (FI-008, 2026-09-25).

Writes a structured receipt {trace_id, actor, step, state} to the local
ledger on every tool call, then best-effort mirrors it to the arifFlow
metabolism ledger (flow_ingest) via the arifFlow MCP door. Mirror failure
is non-fatal: local ledger remains the floor, state recorded honestly.
"""
import hashlib
import json
import os
import sys
import time
import urllib.request

STATE_DIR = os.path.expanduser("~/.cache/arifos-plugin")
LEDGER = os.path.join(STATE_DIR, "receipts.jsonl")
SESSION_FILE = os.path.join(STATE_DIR, "session.json")
ARIFFLOW = "http://127.0.0.1:7073/ingest"  # REST metabolic ledger (schema verified 2026-09-25)
ACTOR = "codex-plugin/arif-irfan"


def trace_id(event: dict) -> str:
    seed = json.dumps(event, sort_keys=True, default=str) + str(time.time_ns())
    return "trx_" + hashlib.sha256(seed.encode()).hexdigest()[:16]


def session() -> dict:
    try:
        with open(SESSION_FILE) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def mirror_to_arifflow(receipt: dict) -> str:
    # FlowReceipt schema (arifFlow/src/receipt.rs) — enums verified live 2026-09-25.
    import uuid
    payload = {
        "receipt_id": str(uuid.uuid4()),
        "created_at": receipt["ts"],
        "actor_id": ACTOR,
        "session_id": receipt.get("session_id") or "unbound",
        "step_type": "Execute",
        "risk_class": "T0Observe",
        "step_number": 1,
        "parent_receipt_ids": [],
        "parent_receipt_hashes": [],
        "supersedes_receipt_ids": [],
        "supersedes_receipt_hashes": [],
        "cost_ns": 0,
        "epistemic_label": "Observation",
        "floor_verdict": "Pass",
        "cooling_decision": "None",
        "payload": {"tool": receipt.get("tool", "unknown"),
                    "local_trace_id": receipt["trace_id"],
                    "source": "arif-irfan post_tool hook"},
    }
    req = urllib.request.Request(
        ARIFFLOW,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=3) as resp:
        return f"mirror:{resp.status}"


def main() -> int:
    raw = sys.stdin.read() if not sys.stdin.isatty() else ""
    try:
        event = json.loads(raw) if raw.strip() else {}
    except ValueError:
        event = {"_raw": raw[:400]}
    receipt = {
        "event": "post_tool.receipt",
        "trace_id": trace_id(event),
        "actor": ACTOR,
        "tool": (event.get("tool_name") or event.get("tool") or "unknown"),
        "session_id": session().get("session_id", ""),
        "state": "MEASURED",
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LEDGER, "a") as fh:
        fh.write(json.dumps(receipt) + "\n")
    try:
        receipt["mirror"] = mirror_to_arifflow(receipt)
        with open(LEDGER, "a") as fh:  # append-back mirror status
            fh.write(json.dumps({**receipt, "event": "post_tool.mirrored"}) + "\n")
    except Exception as exc:
        with open(LEDGER, "a") as fh:
            fh.write(json.dumps({"event": "post_tool.mirror_failed",
                                 "error": str(exc)[:160],
                                 "trace_id": receipt["trace_id"]}) + "\n")
    return 0  # witness lane never blocks


if __name__ == "__main__":
    sys.exit(main())
