#!/usr/bin/env python3
"""stop.py — arif-irfan close lane (FI-008, 2026-09-25).

Best-effort session close: emits an unclosed-transition inventory (every
receipt without a matching close) and reminds the golden path's seal step.
Advisory only — never blocks a stop.
"""
import json
import os
import sys
import time

STATE_DIR = os.path.expanduser("~/.cache/arifos-plugin")
LEDGER = os.path.join(STATE_DIR, "receipts.jsonl")


def main() -> int:
    events = []
    try:
        with open(LEDGER) as fh:
            events = [json.loads(l) for l in fh if l.strip()]
    except (OSError, ValueError):
        pass
    today = time.strftime("%Y-%m-%d", time.gmtime())
    recent = [e for e in events if str(e.get("ts", "")).startswith(today)]
    open_receipts = sum(1 for e in recent if e.get("event") == "post_tool.receipt")
    print(f"[arif-irfan close] receipts today: {open_receipts}; "
          f"ledger: {LEDGER}. Unsealed transitions belong to the next "
          f"seal window — arif_seal on the kernel door when you want "
          f"finality.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
