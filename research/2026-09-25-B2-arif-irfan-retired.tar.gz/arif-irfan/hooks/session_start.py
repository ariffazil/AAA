#!/usr/bin/env python3
"""session_start.py — arif-irfan L0 identity bind (FI-008, 2026-09-25).

Binds a governed federation session via arif_init on the local kernel door,
persists session_id/SCT to the plugin state cache, and prints one bounded
context line for the agent. Offline-safe: federation unreachable -> prints
OBSERVE_ONLY notice, exits 0 (advisory hook; never blocks a session start).
"""
import json
import os
import sys
import urllib.request

STATE_DIR = os.path.expanduser("~/.cache/arifos-plugin")
STATE_FILE = os.path.join(STATE_DIR, "session.json")
LEDGER = os.path.join(STATE_DIR, "receipts.jsonl")
KERNEL = "http://127.0.0.1:8088/mcp"
ACTOR = "codex-plugin/arif-irfan"
CTX_BUDGET = 600  # bounded context injection (additionalContextLimit discipline)


def log_receipt(event: dict) -> None:
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LEDGER, "a") as fh:
        fh.write(json.dumps(event) + "\n")


def main() -> int:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "arif_init",
            "arguments": {
                "actor_id": ACTOR,
                "intent": "codex plugin session bind",
                "requested_authority": "OBSERVE_ONLY",
            },
        },
    }
    req = urllib.request.Request(
        KERNEL,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json",
                 "Accept": "application/json, text/event-stream"},
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            body = resp.read().decode(errors="replace")
            if body.startswith("event:") or body.startswith("data:"):
                body = next(
                    (l[5:].strip() for l in body.splitlines() if l.startswith("data:")),
                    "{}",
                )
        result = json.loads(body)
        inner = result.get("result", {})
        content = inner.get("content", [{}])
        text = content[0].get("text", "{}") if content else "{}"
        try:
            parsed = json.loads(text)
        except (ValueError, TypeError):
            parsed = {}
        sid = parsed.get("session_id") or inner.get("session_id") or ""
        token = parsed.get("session_token") or parsed.get("sct") or ""
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(STATE_FILE, "w") as fh:
            json.dump({"session_id": sid, "session_token": token,
                       "actor": ACTOR, "bound": True}, fh)
        log_receipt({"event": "session.bind", "session_id": sid,
                     "state": "MEASURED", "actor": ACTOR})
        ctx = (f"[arif-irfan] Federation session bound: {sid or 'id-pending'}. "
               f"Golden path: arif_init -> observe -> think -> route -> memory -> "
               f"judge -> forge -> seal. Irreversible class (rm -rf / DROP TABLE / "
               f"force-push main / paid API) is hard-blocked; route mutations "
               f"through judge before forge.")
        print(ctx[:CTX_BUDGET])
        return 0
    except Exception as exc:  # offline / kernel down -> degrade, never block
        log_receipt({"event": "session.bind", "state": "FAILED",
                     "error": str(exc)[:200], "actor": ACTOR})
        print(f"[arif-irfan] Federation unreachable -> OBSERVE_ONLY for new "
              f"authority. Local reversible work continues; no seal, no "
              f"irreversible class. (bind error: {type(exc).__name__})")
        return 0


if __name__ == "__main__":
    sys.exit(main())
