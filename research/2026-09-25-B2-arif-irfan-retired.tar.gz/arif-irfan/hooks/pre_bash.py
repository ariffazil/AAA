#!/usr/bin/env python3
"""pre_bash.py — arif-irfan authority gate (FI-008, 2026-09-25).

Hard-blocks ONLY the F13-ratified irreversible-mutation class, by local
pattern law (works offline; no federation dependency for the block itself).
Everything else: advisory pass + receipt. Pattern list mirrors FI-005's
standing T3 escalation list (Digital Ops Policy 2026-06-30; standing ruling
2026-07-23) — this hook is that list made mechanical, nothing more.

Exit codes: 0 = allow (advisory context on stdout), 2 = BLOCK.
A checker crash is treated as allow-with-receipt (fail-open for usability;
the irreversible patterns below are matched by pure regex, no network, so
the block lane itself cannot be crashed into permissiveness by an outage).
"""
import json
import os
import re
import sys

STATE_DIR = os.path.expanduser("~/.cache/arifos-plugin")
LEDGER = os.path.join(STATE_DIR, "receipts.jsonl")

# F13 irreversible class — hard block. Deliberately narrow.
BLOCK_PATTERNS = [
    r"\brm\s+(-[a-zA-Z]*[rf][a-zA-Z]*\s+)+",      # rm -rf / rm -fr variants
    r"\bDROP\s+(TABLE|DATABASE|SCHEMA)\b",          # SQL irreversible drop
    r"\bgit\s+push\s+.*(--force\b|-f\b)",           # force push (any branch: advisory narrows to main below)
    r"\bgit\s+push\s+--force-with-lease\b.*\bmain\b",
    r">\s*/dev/sd[a-z]",                            # raw device write
    r"\bdd\s+.*\bof=/dev/[a-z]+",
]
# Force-push narrowed: block force to main outright; force to other branches = advisory.
MAIN_FORCE = re.compile(r"\bgit\s+push\b[^\n]*(--force\b(?![\w-])|-f\b)[^\n]*\b(main|master)\b|"
                        r"\bgit\s+push\b[^\n]*\b(main|master)\b[^\n]*(--force\b(?![\w-])|-f\b)")
BLOCK_RES = [re.compile(p, re.IGNORECASE) for p in BLOCK_PATTERNS]


def extract_command(event: dict) -> str:
    for path in (("tool_input", "command"), ("tool_input", "cmd"), ("input", "command"),
                 ("command",), ("cmd",), ("tool", "command")):
        node = event
        for key in path:
            if isinstance(node, dict) and key in node:
                node = node[key]
            else:
                node = None
                break
        if isinstance(node, str):
            return node
    return json.dumps(event) if event else ""


def log_receipt(event: dict) -> None:
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LEDGER, "a") as fh:
            fh.write(json.dumps(event) + "\n")
    except OSError:
        pass


def main() -> int:
    raw = sys.stdin.read() if not sys.stdin.isatty() else ""
    try:
        event = json.loads(raw) if raw.strip() else {}
    except ValueError:
        event = {"_raw": raw[:400]}
    cmd = extract_command(event)

    # 1) Hard lane: irreversible class -> BLOCK (exit 2).
    for rx in BLOCK_RES:
        if cmd and rx.search(cmd):
            if rx.pattern.startswith(r"\bgit\s+push") and not MAIN_FORCE.search(cmd):
                break  # force-push to non-main branch: fall through to advisory
            log_receipt({"event": "pre_bash.block", "state": "MEASURED",
                         "pattern": rx.pattern[:60], "command": cmd[:300]})
            print(f"[arif-irfan BLOCK] Irreversible-mutation class matched "
                  f"(F13 standing list). This needs an explicit 888_HOLD "
                  f"sovereign release, not a hook override. "
                  f"Escalate as a single binary to Arif.")
            return 2

    # 2) Advisory lane: allow + receipt.
    log_receipt({"event": "pre_bash.pass", "state": "MEASURED",
                 "command": cmd[:300] if cmd else "(no command extracted)"})
    return 0


if __name__ == "__main__":
    sys.exit(main())
