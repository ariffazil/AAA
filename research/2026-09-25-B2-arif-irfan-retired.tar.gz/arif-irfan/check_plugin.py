#!/usr/bin/env python3
"""check_plugin.py — local validation of arif-irfan against the documented
Codex plugin rejection rules (plugin-json-spec.md, openai/codex main,
read 2026-09-25). Implements the 8 documented hard rules; the real Rust
validator remains the install-time authority (claim_state: MEASURED against
documented rules, not against the binary)."""
import json
import re
import sys
from pathlib import Path

PLUGIN = Path("/root/.agents/plugins/plugins/arif-irfan")
fail = []


def rule(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fail.append(msg)


m = json.loads((PLUGIN / "plugin.json").read_text())

# R1 real values
for path in [("name",), ("version",), ("description",), ("author", "name"),
             ("interface", "displayName"), ("interface", "shortDescription"),
             ("interface", "category"), ("interface", "capabilities")]:
    node = m
    for k in path:
        node = node.get(k) if isinstance(node, dict) else None
    rule(bool(node) and not re.search(r"TODO|stub|placeholder", str(node), re.I),
         f"real value: {'.'.join(path)}")
# R2 strict semver
rule(bool(re.fullmatch(r"\d+\.\d+\.\d+", m["version"])), f"strict semver: {m['version']}")
# R3 absolute https URLs when present
iface = m.get("interface", {})
for k in ("websiteURL", "privacyPolicyURL", "termsOfServiceURL"):
    v = iface.get(k)
    rule(v is None or str(v).startswith("https://"), f"{k} https-or-absent")
# R4 icon assets exist when referenced
for k in ("composerIcon", "logo", "logoDark"):
    v = iface.get(k)
    rule(v is None or (PLUGIN / v).exists(), f"{k} file-or-absent")
shots = iface.get("screenshots", [])
rule(all((PLUGIN / s).exists() for s in shots) and all(s.endswith(".png") for s in shots),
     "screenshots exist+png")
# R5 apps <-> .app.json
rule(("apps" in m) == (PLUGIN / ".app.json").exists(), "apps pairing consistent (both absent ok)")
# R6 mcpServers path XOR inline
rule(isinstance(m.get("mcpServers"), dict), "mcpServers inline object (not dual-declared)")
for name, cfg in m["mcpServers"].items():
    rule(cfg.get("type") == "http" and str(cfg.get("url", "")).startswith("http"),
         f"mcp door well-formed: {name}")
# R7 unsupported manifest fields (hooks rejected in manifest per validator notes)
rule("hooks" not in m, "no unsupported 'hooks' key in manifest (hooks.json auto-discovered)")
# R8 no TODO placeholders anywhere
todo = [str(p) for p in PLUGIN.rglob("*") if p.is_file() and p.suffix in (".json", ".md", ".py")
        and re.search(r"\[?TODO[:\]]", p.read_text(errors="replace"))]
rule(not todo, f"no TODO placeholders {todo if todo else ''}")
# Companion checks
hk = json.loads((PLUGIN / "hooks.json").read_text())
for ev in ("SessionStart", "PreToolUse", "PostToolUse", "Stop"):
    hs = hk.get("hooks", {}).get(ev, [])
    rule(bool(hs) and all("timeout" in h["hooks"][0] for h in hs), f"hook {ev}: bounded timeout")
mk = json.loads((Path("/root/.agents/plugins/marketplace.json")).read_text())
entry = mk["plugins"][0]
rule(entry["name"] == m["name"], "marketplace name matches manifest")
rule(entry["source"]["source"] == "local" and
     Path("/root/.agents/plugins") / entry["source"]["path"] == PLUGIN, "marketplace path resolves")
for k in ("installation", "authentication"):
    rule(k in entry["policy"], f"marketplace policy.{k} present")
# defaultPrompt caps
dp = iface.get("defaultPrompt", [])
rule(len(dp) <= 3 and all(len(s) <= 128 for s in dp), "defaultPrompt <=3 entries, <=128 chars")

print(f"\n{'ALL GREEN' if not fail else f'{len(fail)} FAILURES'} — claim_state: "
      f"{'MEASURED' if not fail else 'FAILED'} (documented rules; binary validator pending P2)")
sys.exit(1 if fail else 0)
