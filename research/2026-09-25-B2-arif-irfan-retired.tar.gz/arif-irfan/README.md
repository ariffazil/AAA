# arif-irfan — Federated Constitutional Coder (Codex plugin)

> Thin adapter (DITEMPA). Capability lives here; authority never leaves the
> arifOS federation. Forged 2026-09-25 by FI-008 from the deep-research doc
> `/root/AAA/research/2026-09-25-federated-codex-plugins-deep-research.md`
> (convergent with FI-005 Codex session's 41-invariant bridge).

## What it mounts (LOCAL profile — localhost doors, zero external surface)

| Door | URL | Surface |
|---|---|---|
| arifos (kernel) | `http://127.0.0.1:8088/mcp` | canonical 8 |
| aforge | `http://127.0.0.1:7072/mcp` | execution substrate |
| geox | `http://127.0.0.1:8081/mcp` | earth intelligence |
| wealth | `http://127.0.0.1:18082/mcp` | capital intelligence |
| well | `http://127.0.0.1:18083/mcp` | vitality / triad |

## The spine (hooks.json)

- **SessionStart** → binds `arif_init` session; offline → OBSERVE_ONLY notice.
- **PreToolUse [Bash]** → hard-blocks the F13 irreversible list (rm -rf /
  DROP TABLE / force-push main / raw device writes); all else advisory.
  Block lane is pure local regex — no network dependency.
- **PostToolUse** → trace_id receipt to local ledger + best-effort
  `flow_ingest` mirror to arifFlow.
- **Stop** → receipt inventory; seal reminder.

## Skills (pointer, not fork)

`arifos-router` (gap → door) · `init` (ignition) · `seal` (close).
The 555-skill mesh stays server-side — one writer, many views.

## State

`~/.cache/arifos-plugin/` — `session.json`, `receipts.jsonl`.

## Declared unknowns (verify at first live install — P2)

1. Hook payload/env surface actually passed by Codex (handlers are
   defensive: tolerate empty/odd stdin, extract command defensively).
2. Block exit-code convention (uses exit 2, Claude-style; verify against
   the real runner before relying).
3. Hook timeout semantics under load.

## Degradation law

Federation unreachable → OBSERVE_ONLY. The plugin never mints local
authority to keep working.

License: AGPL-3.0-only · Author: ARIF FAZIL
